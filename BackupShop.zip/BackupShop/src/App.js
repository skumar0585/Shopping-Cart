import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Accessories from './components/Accessories';
import MaterialUI from './components/MaterialUI';
import Smartdevice from './components/Smartdevice';
import SingleProduct from './components/SingleProduct';


class App extends Component {
  render() {
    return (
          <Router>
            <div>
            <Header />
            <div className="container-fluid">
              <div className="row">
                    <Switch>
                    <Route exact path='/' component={Home} />
                    <Route path='/Accessories' component={Accessories} />
                    <Route path='/Smartdevice' component={Smartdevice} />
                    <Route path='/MaterialUI' component={MaterialUI} />
                    <Route path='/About' component={About} />
                    <Route path='/Contact' component={Contact} />
                    <Route path='/SingleProduct/:id' component={SingleProduct} />
                    </Switch>
                    </div>
               </div>
            </div>
          </Router>

    );
  }
}

export default App;
