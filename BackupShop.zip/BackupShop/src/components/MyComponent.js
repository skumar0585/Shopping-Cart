import React from 'react';
import { Table, TableBody, TableHeader, TableHeaderColumn, TableRow, TableRowColumn, } from 'material-ui/Table';


import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import AppBar from 'material-ui/AppBar';



const MyComponent = () => (
  <Table>
    <TableHeader>
      <TableRow>
        <TableHeaderColumn>Product ID</TableHeaderColumn>
        <TableHeaderColumn>Product Name</TableHeaderColumn>
        <TableHeaderColumn>Product Status</TableHeaderColumn>
      </TableRow>
    </TableHeader>
    <TableBody>
      <TableRow>
        <TableRowColumn>1</TableRowColumn>
        <TableRowColumn>Mi Bluetooth</TableRowColumn>
        <TableRowColumn>Avialble</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>2</TableRowColumn>
        <TableRowColumn>Mi Smart Band</TableRowColumn>
        <TableRowColumn>Not Avialble</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>3</TableRowColumn>
        <TableRowColumn>Mi Earphone</TableRowColumn>
        <TableRowColumn>Avialble</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>4</TableRowColumn>
        <TableRowColumn>Mi Power Bank</TableRowColumn>
        <TableRowColumn>Not Avialble</TableRowColumn>
      </TableRow>
      <TableRow>
        <TableRowColumn>5</TableRowColumn>
        <TableRowColumn>Mi VR</TableRowColumn>
        <TableRowColumn>Avialble</TableRowColumn>
      </TableRow>
        <TableRow>
        <TableRowColumn>6</TableRowColumn>
        <TableRowColumn>Mi USB</TableRowColumn>
        <TableRowColumn>Avialble</TableRowColumn>
      </TableRow>
    </TableBody>
  </Table>
);

export default MyComponent;