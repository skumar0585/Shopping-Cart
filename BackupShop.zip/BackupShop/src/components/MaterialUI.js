import React, { Component } from 'react';
import MyComponent from './MyComponent';
import {grey800, pinkA200, red500
} from 'material-ui/styles/colors';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import getMuiTheme from 'material-ui/styles/getMuiTheme';


const muiTheme = getMuiTheme({
  palette: {
    textColor: grey800,
    primary1Color:red500,
  },
});
class MaterialUI extends Component {

	render() {
		return(
				<div className="abtBg">
						 <MuiThemeProvider muiTheme={muiTheme}>
          					<MyComponent />
       					 </MuiThemeProvider>	
				</div>
			);
	}
}

export default MaterialUI;