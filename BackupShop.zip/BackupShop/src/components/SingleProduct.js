import React, { Component } from 'react';
import data from '../data.json';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import Buybutton from './Buybutton';

class SingleProduct extends Component {
    render() {
        var singleProduct = data.filter(xData => xData.productId === this.props.match.params.id);
        //return singleProduct;
        return (
            <div className="SingleProduct">
                <div className="col-md-12 viewpro margBottom15">
                    <img src={require(`../images/product/${singleProduct[0].productImage}`)} />
                    <h3 className="title">{singleProduct[0].productTitle}</h3>
                    <p className="price">₹ {singleProduct[0].productPrice}</p>
                      <MuiThemeProvider>
                    <Buybutton />
                </MuiThemeProvider>
                </div>
              
            </div>
        );
    }
}

export default SingleProduct;