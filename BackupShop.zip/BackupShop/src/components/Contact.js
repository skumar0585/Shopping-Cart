import React, { Component } from 'react';

class Contact extends Component {
	render() {
		return(
				<div className="contBg bgWrap">
					<p>Contact Component</p>
				</div>
			);
	}
}

export default Contact;