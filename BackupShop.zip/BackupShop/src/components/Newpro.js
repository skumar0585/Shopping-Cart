import React, { Component } from 'react';

class Newpro extends Component {
	render() {
		return (
			<div className="containerPad15 newPro">
				<div className="row">
					<div className="col-md-4 img-res">
						<img src={require('../images/pro1.jpg')} alt="pro1" />
					</div>
					<div className="col-md-4 img-res">
						<img src={require('../images/pro2.png')} alt="pro2" />
					</div>
					<div className="col-md-4 img-res">
						<img src={require('../images/pro3.jpg')} alt="pro3" />
					</div>
				</div>
			</div>
			);
	}
}

export default Newpro;