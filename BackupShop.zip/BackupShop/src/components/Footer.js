import React, { Component } from 'react';

class Footer extends Component {
	render() {
		return(
				<div className="foot">
					<p>Copyright &copy; 2018 reactshopingcart. All Rights Reserved</p>
				</div>
			);
	}
}

export default Footer;