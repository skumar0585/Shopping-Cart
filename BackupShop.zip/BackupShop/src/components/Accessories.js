import React, { Component } from 'react';

class Accessories extends Component {
    render() {
        return(
                <div className="contBg bgWrap">
                    <p>Accessories Component</p>
                </div>
            );
    }
}

export default Accessories;