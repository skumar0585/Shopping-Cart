import React from 'react';
import RaisedButton from 'material-ui/RaisedButton';



const style = {
  margin: 0,
   width: '200px',

};

const Buybutton = () => (
  <div>
    <RaisedButton label="BUY NOW" secondary={true} style={style} />
  </div>
);

export default Buybutton;