import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Accessories from './components/Accessories';
import Smartdevice from './components/Smartdevice';


class App extends Component {
  render() {
    return (
          <Router>
            <div>
            <Header />
            <div className="container-fluid">
              <div className="row">
                    <Switch>
                    <Route exact path='/' component={Home} />
                     <Route path='/Accessories' component={Accessories} />
                    <Route path='/Smartdevice' component={Smartdevice} />
                    <Route path='/About' component={About} />
                    <Route path='/Contact' component={Contact} />

                    </Switch>
                    </div>
               </div>
            </div>
          </Router>

    );
  }
}

export default App;
