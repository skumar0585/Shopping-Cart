import React, { Component } from 'react';

class Newpro extends Component {
	render() {
		return (
			<div className="containerPad15">
				<div className="row">
					<div className="col-md-4 img-res">
						<img src={require('../images/pro1.jpg')} />
					</div>
					<div className="col-md-4 img-res">
						<img src={require('../images/pro2.png')} />
					</div>
					<div className="col-md-4 img-res">
						<img src={require('../images/pro3.jpg')} />
					</div>
				</div>
			</div>
			);
	}
}

export default Newpro;