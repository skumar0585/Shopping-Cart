import React, { Component } from 'react';
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom';

class Header extends Component {
	render() {
		return (
				<nav className="navbar navbar-inverse">
					<div className="container">
					<div className="navbar-header">
				      <button type="button" className="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				        <span className="icon-bar"></span>
				        <span className="icon-bar"></span>
				        <span className="icon-bar"></span>                        
				      </button>
				      <Link to={'/'}>LOGO</Link>
				    </div>
						<div className="collapse navbar-collapse" id="myNavbar">
							<ul className="nav navbar-nav">
								<li className="active"><Link to={'/'}>Home</Link></li>
								<li><Link to={'/Accessories'}>Accessories</Link></li>
								<li><Link to={'/Smartdevice'}>Smart Devices</Link></li>
                            	<li><Link to={'/About'}>About</Link></li>
                            	<li><Link to={'/Contact'}>Contact Us</Link></li>
							</ul>
							<ul className="nav navbar-nav navbar-right">
					        <li><a href="#"><span className="glyphicon glyphicon-user"></span> Sign Up</a></li>
					        <li><a href="#"><span className="glyphicon glyphicon-log-in"></span> Login</a></li>
					      </ul>
						</div>
					</div>
				</nav>
			);
	}
}
export default Header;