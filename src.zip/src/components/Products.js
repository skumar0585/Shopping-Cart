import React, { Component } from 'react';
import data from '../data.json';
import { Link } from 'react-router-dom';


class Products extends Component {
	render() {
		var rows = data.map(function(prod, index){
			return 		<Link to={''}>
						<div className="col-md-4 thumb margBottom15">
							<img src={require(`../images/product/${prod.productImage}`)} />
							<h3 className="title">{prod.productTitle}</h3>
							<p className="price">₹ {prod.productPrice}</p>
						</div>
						</Link>
						
		});
		return (

			<div className="prodbg sectionPad">
				<div className="text-center">
				<h3>START PRODUCTS</h3>
					<div className="strip text-center"><img src={require('../images/skill.png')} /></div>
					<div className="row prodMar30 productImg">
					<div className="col-md-3">
						<div className="col-md-3">
							<img src={require('../images/note5.jpg')} />
						</div>
					</div>
					<div className="col-md-9 prodImgSec">
						{rows}
					</div>
				</div>
				</div>
			</div>

				
			);
	}
}

export default Products;