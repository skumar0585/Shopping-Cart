import React, { Component } from 'react';

class Smartdevice extends Component {
	render() {
		return(
				<div className="contBg bgWrap">
					<p>Smart Devices Component</p>
				</div>
			);
	}
}

export default Smartdevice;