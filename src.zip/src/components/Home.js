import React, { Component } from 'react';
import Banner from './Banner';
import Newpro from './Newpro';
import Products from './Products';
import Footer from './Footer';


class Home extends Component {
	render() {
		return(
				<div>
					<Banner />
					<Newpro />
					<Products />
					<Footer />
					
				
				</div>
			);
	}
}

export default Home;