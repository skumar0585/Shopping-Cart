import React, { Component } from 'react';
import data from '../data.json';
class Products extends Component {
	render() {
		return (
				<div className="prodbg sectionPad">
				<div className="text-center">
				<h3>START PRODUCTS</h3>
					<div className="strip text-center"><img src={require('../images/skill.png')} /></div>
				
				<div className="row prodMar30 productImg">
					<div className="col-md-3">
						<div className="col-md-3">
							<img src={require('../images/note5.jpg')} />
						</div>
					</div>
					<div className="col-md-9 prodImgSec">
						<div className="col-md-4 thumb margBottom15">
							<img src={require('../images/product/bluetooth.jpg')} />
							<h3 className="title"><a href="#">Mi Bluetooth Headset</a></h3>
							<p className="price">₹ 899 onwards</p>
						</div>
						<div className="col-md-4 thumb margBottom15">
							<img src={require('../images/product/smartband.jpg')} />
							<h3 className="title"><a href="#">Mi Smart Band</a></h3>
							<p className="price">₹ 1200 onwards</p>
						</div>
						<div className="col-md-4 thumb margBottom15">
							<img src={require('../images/product/earphone.jpg')} />
							<h3 className="title"><a href="#">Mi Earphone</a></h3>
							<p className="price">₹ 599 onwards</p>
						</div>
						<div className="col-md-4 thumb">
							<img src={require('../images/product/powerbank.jpg')} />
							<h3 className="title"><a href="#">Mi Power Bank</a></h3>
							<p className="price">₹ 799 onwards</p>
						</div>
						<div className="col-md-4 thumb">
							<img src={require('../images/product/vr.jpg')} />
							<h3 className="title"><a href="#">Mi VR</a></h3>
							<p className="price">₹ 399 onwards</p>
						</div>
						<div className="col-md-4 thumb">
							<img src={require('../images/product/usb.jpg')} />
							<h3 className="title"><a href="#">Mi Duel USB</a></h3>
							<p className="price">₹ 299 onwards</p>
						</div>
					</div>
				</div>
				</div>
			</div>
			);
	}
}

export default Products;